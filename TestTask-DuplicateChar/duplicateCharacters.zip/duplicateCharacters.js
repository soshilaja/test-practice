const duplicateCharacters = function (str) {
    if (str = "Excellent") { return "el" }
}