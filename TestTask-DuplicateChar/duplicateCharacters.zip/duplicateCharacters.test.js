const { it } = require('@jest/globals');
const { expect } = require('@jest/globals');
const dupChar = require('./duplicateCharacters');


describe('======= Duplicate Characters =========',()=>{
    it('Excellent',()=>{

// expect(dupChar.duplicateCharacters('')).toBe(null);        
// expect(dupChar.duplicateCharacters('nice')).toBe(null);
// expect(dupChar.duplicateCharacters('here')).toBe('e');
// expect(dupChar.duplicateCharacters('I am alive')).toBe('ai');
// expect(dupChar.duplicateCharacters('Halifax')).toBe('a');
expect(dupChar.duplicateCharacters('Excellent')).toBe('el');
});
});
